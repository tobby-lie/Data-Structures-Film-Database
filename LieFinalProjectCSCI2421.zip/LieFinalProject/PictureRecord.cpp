//Tobby Lie
//CSCI 2421
//Final Project
//October 20, 2017
//PictureRecord class implementation

#include "PictureRecord.h"


// default constructor
PictureRecord::PictureRecord():name(""), year(""),nomination(""),rating(""),duration(""),genre1(""),genre2(""), release(""),metacritic(""),synopsis(""){} // end PictureRecord
