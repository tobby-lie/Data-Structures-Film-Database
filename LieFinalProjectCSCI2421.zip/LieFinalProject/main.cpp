//Tobby Lie
//CSCI 2421
//Final Project
//October 20, 2017
//Program utilizes vectors and Binary Search Trees
//in order to implement a database

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "Functions.h"
#include "PictureBST.h"

using namespace std;

int main(){

    menu();
    
return 0;
    
}
