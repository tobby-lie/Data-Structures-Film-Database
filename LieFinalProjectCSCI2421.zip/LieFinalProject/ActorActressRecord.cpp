//Tobby Lie
//CSCI 2421
//Final Project
//October 20, 2017
//ActorActressRecord class implementation

#include <iostream>
#include "ActorActressRecord.h"


// default constructor
ActorActressRecord::ActorActressRecord():year(""), award(""), winner(true), name(""), film(""){} // end ActorActressRecord



























































